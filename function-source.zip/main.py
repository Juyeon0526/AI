import numpy as np
import pandas as pd

import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

def ssd_rtdb(event, context):
    import numpy as np
    import pandas as pd

    import firebase_admin
    from firebase_admin import credentials
    from firebase_admin import db

    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.feature_extraction.text import TfidfVectorize
    """Triggered by a change to a Firebase RTDB reference.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    user_id = context.resource

    cred = credentials.Certificate('gfi-rec-firebase-adminsdk-j8kaf-b945a590a2.json')
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://gfi-rec-default-rtdb.firebaseio.com/'
    })
    
    prod_id= db.reference().child('rec_choice').child(user_id).child('prod_id')
    min_price = db.reference().child('rec_choice').child(user_id).child('min_price')
    max_price = db.reference().child('rec_choice').child(user_id).child('max_price')
    purpose_category = db.reference().child('rec_choice').child(user_id).child('purpose_category')
    # 1 - 문서작업  2 - 강의  3 - 5 게임(저,중,고)  6 - 영상편집  7 - 3D그래픽  8 - 프로그래밍
    
    #파이어베이스 데이터 불러오기
    ref = db.reference().child(prod_id)   
    # Create a query against the collection
    #ref.where(u'price', u'>=', v2).where(u'price', u'<=', v3).stream()
    rows = ref.get() #데이터 저장
    #colname = ref.description
    col = {'img_url','price','prod_code', 'prod_id', 'prod_info', 'prod_name'}
    # 컬럼명 추출해서 컬럼 리스트 생성
    # for i in colname: col.append(i[0])

    # 데이터 프레임 생성해서 값 넣기
    raw = pd.DataFrame(list(rows), columns=col)
    #raw[['prod_code', 'prod_id', 'prod_name', 'img_url', 'prod_info', 'price']]
    raw['price']=pd.to_numeric(raw['price'])
    
    #raw.drop(raw.loc[raw['price']<v2].index, inplace=True)
    #raw.drop(raw.loc[raw['price']>v3].index, inplace=True)
            
    raw_len = len(raw)

    result = []
    for item in raw['prod_info']:
        result.append(item)

    num = len(result)

    # 가상유저 딕셔너리 - SSD
    virture_user = {
        1: '내장형SSD 64cm25형 SATA3 6Gb/s 순차읽기 555MB/s 순차쓰기 540MB/s 읽기IOPS 79K 쓰기IOPS 87K MTBF 150만시간 A/S기간 3년 두께 7mm 46g',
        2: '내장형SSD 64cm25형 SATA3 6Gb/s 순차읽기 560MB/s 순차쓰기 510MB/s 읽기IOPS 최대 95K  쓰기IOPS 최대 90K MTBF 180만시간 A/S기간 5년  두께 7mm',
        3: '내장형SSD 64cm25형 SATA3 6Gb/s 순차읽기 560MB/s 순차쓰기 510MB/s 읽기IOPS 최대 95K  쓰기IOPS 최대 90K MTBF 180만시간 A/S기간 5년  두께 7mm',
        4: '내장형SSD M2 2280 PCIe40x4 64GT/s NVMe 순차읽기 4900MB/s 순차쓰기 400MB/s 읽기IOPS 750K 쓰기IOPS 700K MTBF 170만시간 A/S기간 3년 두께 157mm 45g',
        5: '내장형SSD 64cm25형 SATA3 6Gb/s 순차읽기 560MB/s 순차쓰기 510MB/s 읽기IOPS 최대 95K  쓰기IOPS 최대 90K MTBF 180만시간 A/S기간 5년  두께 7mm',
        6: '내장형SSD M2 2280 PCIe30x4 32GT/s NVMe 13 순차읽기 2300MB/s 순차쓰기 900MB/s  MTBF 180만시간 A/S기간 3년 데이터 복구 1년 두께 215mm 7g',
        7: '내장형SSD 64cm25형 SATA36Gb/s 순차읽기 535MB/s  순차쓰기 최대 370MB/s 읽기IOPS 최대 87K  쓰기IOPS 최대 70K A/S기간 3년 두께 7mm',
        8: '내장형SSD 64cm25형 SATA3 6Gb/s 순차읽기 560MB/s 순차쓰기 510MB/s 읽기IOPS 최대 95K  쓰기IOPS 최대 90K MTBF 180만시간 A/S기간 5년  두께 7mm'
    }

    # 가상유저 추가
    add_vu = virture_user[purpose_category]
    result.append(add_vu)

    vect = CountVectorizer()
    countvect = vect.fit_transform(result)
    countvect.toarray()
    sorted(vect.vocabulary_)
    countvect_df = pd.DataFrame(countvect.toarray(), columns=sorted(vect.vocabulary_))
    cosine_matrix = cosine_similarity(countvect_df, countvect_df)
    np.round(cosine_matrix, 4)  # 원하는 소수점 자리수에서 반올림
    vect = TfidfVectorizer()
    tfvect = vect.fit(result)
    tfidv_df = pd.DataFrame(tfvect.transform(result).toarray(), columns=sorted(vect.vocabulary_))

    for column_name, item in tfidv_df.iteritems():
        if 'TB' in column_name:
            tfidv_df[column_name] = item + 0.01
        if 'tb' in column_name:
            tfidv_df[column_name] = item + 0.01
        if 'mb' in column_name:
            tfidv_df[column_name] = item + 0.008
        if 'MB' in column_name:
            tfidv_df[column_name] = item + 0.006
        if 'RPM' in column_name:
            tfidv_df[column_name] = item + 0.004
        if 'rpm' in column_name:
            tfidv_df[column_name] = item + 0.004
        if '년' in column_name:
            tfidv_df[column_name] = item + 0.002

    cosine_matrix = cosine_similarity(tfidv_df, tfidv_df)
    vect = TfidfVectorizer(max_features=5)
    tfvect = vect.fit(result)
    tfidv_df = pd.DataFrame(tfvect.transform(result).toarray(), columns=sorted(vect.vocabulary_))

    pro2id = {}
    for i, c in enumerate(raw['prod_name']): pro2id[i] = c
    pro2id[num] = 'virture_user'
    id2pro = {}
    for i, c in pro2id.items(): id2pro[c] = i

    # id 추출
    idx = id2pro['virture_user']  # 가상유저 - 마지막 인덱스
    sim_scores = [(i, c) for i, c in enumerate(cosine_matrix[idx]) if i != idx]  # 제품들의 유사도 및 인덱스를 추출
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)  # 유사도가 높은 순서대로 정렬
    #sim_scores[0:10]  # 상위 10개의 인덱스와 유사도를 추출


    # 인덱스를 Title로 변환
    sim_scores = [(pro2id[i], score) for i, score in sim_scores[0:10]]
            
    rec_ref = db.reference().child('rec').child(v5)
    rec_ref.set({'1': sim_scores[0][0],
                 '2': sim_scores[1][0],
                 '3': sim_scores[2][0],
                 '4': sim_scores[3][0],
                 '5': sim_scores[4][0],
                 '6': sim_scores[5][0],
                 '7': sim_scores[6][0],
                 '8': sim_scores[7][0],
                 '9': sim_scores[8][0],
                 '10': sim_scores[9][0]})    
